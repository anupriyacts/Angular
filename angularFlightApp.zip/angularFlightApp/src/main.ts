//import { Component, NgModule } from "@angular/core";
//import { BrowserModule } from "@angular/platform-browser";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { AppModule } from "./loginform/app.module";

console.log("This is main ts")

platformBrowserDynamic().bootstrapModule(AppModule);