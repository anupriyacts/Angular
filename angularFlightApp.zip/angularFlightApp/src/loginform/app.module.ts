import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { SearchComponent } from './components/search/search.component';
import { BookingComponent } from './components/booking/booking.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminpageComponent } from './components/adminpage/adminpage.component';
import { AddflightComponent } from './components/addflight/addflight.component';
import { AddairlineComponent } from './components/addairline/addairline.component';
import { RetriveAllFlightsComponent } from './components/retrive-all-flights/retrive-all-flights.component';
import { CancelTicketComponent } from './components/cancel-ticket/cancel-ticket.component';
import { SearchflightComponent } from './components/searchflight/searchflight.component';

const routes:Routes = [
  
  {path: "login", component: LoginComponent},
  {path: "home", component: HomeComponent},
  {path: "search", component: SearchComponent},
  {path: "booking", component: BookingComponent},
  {path: "adminpage",component: AdminpageComponent},
  {path: "addflight", component: AddflightComponent},
  {path: "addairline", component: AddflightComponent},
  {path: "cancel-ticket", component: CancelTicketComponent},
  {path: "**", redirectTo: "home"}
]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    HomeComponent,
    SearchComponent,
    BookingComponent,
    AdminpageComponent,
    AddflightComponent,
    AddairlineComponent,
    RetriveAllFlightsComponent,
    CancelTicketComponent,
    SearchflightComponent
  ],
  imports: [
    BrowserModule, ReactiveFormsModule, RouterModule.forRoot(routes), HttpClientModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
