import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.scss']
})
export class AdminpageComponent implements OnInit {

 constructor(private router: Router) { }

  ngOnInit(): void {
  }
  addFlight(): void{
    this.router.navigate(['addflight']);
  }
  addAirline(): void{
    this.router.navigate(['addairline']);
  }
  
}
