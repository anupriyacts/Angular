import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class RetriveFlightService {
  public Url = 'http://localhost:9050';
  constructor(private http: HttpClient) { }
  viewFlight(flight: Object): Observable<Object> {
    return this.http.post(`${this.Url}/searchFlights/`,flight);
  } 
  deleteBooking(pnr: number): Observable<any> {
    //return this.http.delete(`${this.Url}/searchFlights/booking/cancel/pnr`, { responseType: 'text' });
   
    let url : string = "http://localhost:9050/searchFlights/booking/cancel"+pnr;
    return this.http.delete<String>(url).pipe
    (catchError(this.handleError));
  }
  private handleError(err:HttpErrorResponse){
    let errString : string ='';
    console.log(err);
    return errString;
  }
}