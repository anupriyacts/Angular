import { Time } from "@angular/common";

export class Flight{
    constructor(
    public flightId: number,
    public airlineName:string,
    public flightName:string,
    public source:string, 
    public destination:string,
    public departureDate:Date,
    public departureTime:Time,
    public arrivalDate:Date,
	public arrivalTime:Time,
	public price:number,
	public businessClassSeats : number,
	public nonBusinessClassSeats:number,
	public totalSeatsAvailable:number
     ){}
   
}