import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addairline',
  templateUrl: './addairline.component.html',
  styleUrls: ['./addairline.component.scss']
})
export class AddairlineComponent implements OnInit {

  addairlineform:FormGroup;

  constructor(private router:Router) {

    this.addairlineform = new FormGroup({
      airlineName : new FormControl("", [
        Validators.required,
        
      ]),
      source : new FormControl("", [
        Validators.required,
      ])
     
   });

 }

  ngOnInit(): void {
  }
  addNewAirline()
  {
    console.log(this.addairlineform.value)
   
    this.router.navigate(["adminpage"]);
  }
}
