import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { RetriveFlightService } from '../services/retriveAllFlights-service';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.scss']
})
export class CancelTicketComponent implements OnInit {

  cancelForm:FormGroup;
  constructor(private flightService: RetriveFlightService, private router:Router) {
    this.cancelForm = new FormGroup({
      pnr : new FormControl("", [
        Validators.required
       
      ])
    
   });
  }

ngOnInit(): void {
}
getCancelInfo()
{
  console.log(this.cancelForm.value)
  confirm("Ticket cancelled !");
  this.deleteBooking(this.cancelForm.value);
  //this.router.navigate(["home"]);
}

deleteBooking(pnr: number) {
  this.flightService.deleteBooking(pnr)
  .subscribe(
    data=> {
      console.log(data);
     
    },
    error => console.log(error)
  );
}
}