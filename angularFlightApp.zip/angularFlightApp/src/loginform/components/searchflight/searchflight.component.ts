import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchflight',
  templateUrl: './searchflight.component.html',
  styleUrls: ['./searchflight.component.scss']
})
export class SearchflightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
