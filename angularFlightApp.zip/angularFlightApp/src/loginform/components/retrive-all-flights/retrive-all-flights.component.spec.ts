import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetriveAllFlightsComponent } from './retrive-all-flights.component';

describe('RetriveAllFlightsComponent', () => {
  let component: RetriveAllFlightsComponent;
  let fixture: ComponentFixture<RetriveAllFlightsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetriveAllFlightsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RetriveAllFlightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
