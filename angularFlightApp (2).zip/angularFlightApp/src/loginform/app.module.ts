import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { SearchComponent } from './components/search/search.component';
import { BookingComponent } from './components/booking/booking.component';
import { RouterModule, Routes } from '@angular/router';

const routes:Routes = [
  
  {path: "login", component: LoginComponent},
  {path: "home", component: HomeComponent},
  {path: "search", component: SearchComponent},
  {path: "booking", component: BookingComponent},
  {path: "**", redirectTo: "home"}
]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    HomeComponent,
    SearchComponent,
    BookingComponent
  ],
  imports: [
    BrowserModule, ReactiveFormsModule, RouterModule.forRoot(routes)
   
  ],
  //providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
